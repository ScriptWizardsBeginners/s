# Standard Library Imports
import os
import time
import json
import logging
import uuid
import threading
from threading import Lock
from functools import wraps
import re
import subprocess
import shutil
import tempfile
import imghdr
import random
import string

# pdf to imgs
from .forms import PDFUploadForm
from pdf2image import convert_from_path

# remove bg
# import io
# from PIL import Image
# from rembg import remove

# HEIC TO JPG

from pillow_heif import register_heif_opener


# Third-Party Libraries
import requests
from bs4 import BeautifulSoup
from PIL import Image  # Image manipulation
from gtts import gTTS  # Text-to-speech conversion
import yt_dlp  # YouTube/Twitch/100+ sites downloader
import pyotp  # 2FA/TOTP implementation
import img2pdf  # img2pdf converter

# Django Core
from django.conf import settings
from django.shortcuts import render,redirect
from django.http import FileResponse,HttpResponse, HttpResponseNotFound, JsonResponse
from django.core.files.storage import default_storage,FileSystemStorage
from django.core.validators import URLValidator, ValidationError

# Django Decorators
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from django.contrib import messages
from .models import *


# Home Page
def index(request):
    return render(request, 'index.html')
#service Page 
def pricing(request):
    return render(request, 'pricing.html')
#service Page 
def service(request):
    return render(request, 'service.html')
#About Page 
def about(request):
    return render(request, 'about.html')
#Contact Page 
def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        contact = Contact(name=name,email=email, subject=subject, message=message)
        contact.save()
        messages.success(request,"Thank you for contacting us!")
        return redirect('contact')

    return render(request, 'contact.html')



# Categories ==================================
def Aipoweredtools(request):
    return render(request, 'Categories/aipoweredtools.html')

def Aicreativetools(request):
    return render(request, 'Categories/aicreativetools.html')

def Analytictools(request):
    return render(request, 'Categories/analytictools.html')

def Blockchaintools(request):
    return render(request, 'Categories/blockchaintools.html')

def Healthtools(request):
    return render(request, 'Categories/healthtools.html')

def Productivitytools(request):
    return render(request, 'Categories/productivitytools.html')

def Securitytools(request):
    return render(request, 'Categories/securitytools.html')

def Socialmediatools(request):
    return render(request, 'Categories/socialmediatools.html')

def Trendbasedtools(request):
    return render(request, 'Categories/trendbasedtools.html')

def Utilitytools(request):
    return render(request, 'Categories/utilitytools.html')


# ======================== Tools ==================================================

# ====================== AI Powered Tools ==================
# ======================== Tool- 1 ============================
def Texttospeech(request):
    # Full list of supported languages
    supported_languages = {
        'af-ZA': 'Afrikaans (South Africa)',
        'sq-AL': 'Albanian (Albania)',
        'ar-SA': 'Arabic (Saudi Arabia)',
        'as-IN': 'Assamese (India)',
        'az-AZ': 'Azerbaijani (Azerbaijan)',
        'bn-BD': 'Bangla (Bangladesh)',
        'bn-IN': 'Bangla (India)',
        'bs-BA': 'Bosnian (Bosnia and Herzegovina)',
        'ca-ES': 'Catalan (Spain)',
        'cs-CZ': 'Czech (Czech Republic)',
        'cy-GB': 'Welsh (United Kingdom)',
        'da-DK': 'Danish (Denmark)',
        'de-DE': 'German (Germany)',
        'el-GR': 'Greek (Greece)',
        'en-US': 'English (US)',
        'en-GB': 'English (UK)',
        'es-ES': 'Spanish (Spain)',
        'et-EE': 'Estonian (Estonia)',
        'eu-ES': 'Basque (Spain)',
        'fa-IR': 'Persian (Iran)',
        'fi-FI': 'Finnish (Finland)',
        'fil-PH': 'Filipino (Philippines)',
        'fr-FR': 'French (France)',
        'ga-IE': 'Irish (Ireland)',
        'gl-ES': 'Galician (Spain)',
        'gu-IN': 'Gujarati (India)',
        'hi-IN': 'Hindi (India)',
        'hr-HR': 'Croatian (Croatia)',
        'hu-HU': 'Hungarian (Hungary)',
        'id-ID': 'Indonesian (Indonesia)',
        'it-IT': 'Italian (Italy)',
        'ja-JP': 'Japanese (Japan)',
        'km-KH': 'Khmer (Cambodia)',
        'kn-IN': 'Kannada (India)',
        'ko-KR': 'Korean (South Korea)',
        'la-LA': 'Latin (Latin)',
        'lv-LV': 'Latvian (Latvia)',
        'mk-MK': 'Macedonian (North Macedonia)',
        'ml-IN': 'Malayalam (India)',
        'mr-IN': 'Marathi (India)',
        'ms-MY': 'Malay (Malaysia)',
        'ms-SG': 'Malay (Singapore)',
        'ne-NP': 'Nepali (Nepal)',
        'nl-NL': 'Dutch (Netherlands)',
        'no-NO': 'Norwegian (Norway)',
        'pl-PL': 'Polish (Poland)',
        'pt-PT': 'Portuguese (Portugal)',
        'pt-BR': 'Portuguese (Brazil)',
        'ro-RO': 'Romanian (Romania)',
        'ru-RU': 'Russian (Russia)',
        'sk-SK': 'Slovak (Slovakia)',
        'sl-SI': 'Slovenian (Slovenia)',
        'sr-RS': 'Serbian (Serbia)',
        'sv-SE': 'Swedish (Sweden)',
        'sw-KE': 'Swahili (Kenya)',
        'ta-IN': 'Tamil (India)',
        'ta-LK': 'Tamil (Sri Lanka)',
        'te-IN': 'Telugu (India)',
        'th-TH': 'Thai (Thailand)',
        'tr-TR': 'Turkish (Turkey)',
        'uk-UA': 'Ukrainian (Ukraine)',
        'vi-VN': 'Vietnamese (Vietnam)',
        'xh-ZA': 'Xhosa (South Africa)',
        'zh-CN': 'Chinese (Simplified)',
        'zh-TW': 'Chinese (Traditional)',
        'zu-ZA': 'Zulu (South Africa)',
    }

    # Sorting the dictionary alphabetically by language name
    sorted_languages = dict(sorted(supported_languages.items(), key=lambda item: item[1]))

    # Pass the sorted dictionary to the template context
    context = {'supported_languages': sorted_languages}

    if request.method == 'POST':
        text = request.POST.get('textInput', '').strip()
        language = request.POST.get('language', 'en-US')  # Get the language selection (defaults to 'en-US')

        # Check if the language is supported by gTTS
        if language not in supported_languages:
            return JsonResponse({'error': f"Language '{language}' is not supported."}, status=400)

        # Check if text is provided
        if not text:
            return JsonResponse({'error': 'No text to speak'}, status=400)

        # Create a temporary directory for the audio file
        temp_dir = tempfile.mkdtemp(prefix="audio_")
        temp_audio_path = os.path.join(temp_dir, "speech.mp3")

        try:
            # Try generating the audio file using gTTS
            tts = gTTS(text=text, lang=language, slow=False)
            tts.save(temp_audio_path)

            # Serve the file without download prompt (inline)
            response = FileResponse(open(temp_audio_path, 'rb'), content_type='audio/mpeg')
            return response
        except Exception as e:
            # Log the exception to get more details about the error
            return JsonResponse({'error': f"Error generating speech for language '{language}': {str(e)}"}, status=500)
        finally:
            # Clean up temporary files
            if os.path.exists(temp_audio_path):
                os.remove(temp_audio_path)
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)

    return render(request, 'tools/aipowerdtools/texttospeech.html', context)

# ======================== Tool- 2 ============================
@csrf_exempt
def Speechtotext(request):
    if request.method == 'POST' and request.FILES.get('audio'):
        audio_file = request.FILES['audio']
        
        # Use a speech recognition library (e.g., SpeechRecognition)
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_file) as source:
            audio_data = recognizer.record(source)
            try:
                transcription = recognizer.recognize_google(audio_data)
                return JsonResponse({'status': 'success', 'transcription': transcription})
            except Exception as e:
                return JsonResponse({'status': 'error', 'message': str(e)})
    
    # Render the form for GET requests
    return render(request, 'tools/aipowerdtools/speechtotext.html')


# ======================== Tool- 3 ============================
def VoiceCloning(request):
    return render(request, 'tools/aipowerdtools/voicecloning.html')
# ======================== Tool- 4 ============================
def Contentgenerator(request):
    return render(request, 'tools/aipowerdtools/aicontentgenerator.html')
# ======================== Tool- 4 ============================
def Storygenerator(request):
    return render(request, 'tools/aipowerdtools/aistorygenerator.html')
# ======================== Tool- 5 ============================
def Resumebuilder(request):
    return render(request, 'tools/aipowerdtools/airesumebuilder.html')
# ======================== Tool- 6 ============================
def Videosummarizer(request):
    return render(request, 'tools/aipowerdtools/aivideosummarizer.html')
# ======================== Tool- 7 ============================
def Presentation(request):
    return render(request, 'tools/aipowerdtools/aipresentation.html')
# ======================== Tool- 8 ============================

# ======================== Tool- 9 ============================
def Chatbotbuilder(request):
    return render(request, 'tools/aipowerdtools/chatbotbuilder.html')
# ======================== Tool- 10 ============================



# ====================== Blockchain Tools ==================
def BlockchainWalletAddress(request):
    return render(request, 'tools/blockchaintools/blockchainwalletadv.html')



# ====================== Utility Tools ====================================







# ==============HEIC TO JPG ===============

register_heif_opener()

def delete_files(heic_path, jpg_path, delay=20):
    """Delete files after a specified delay (default: 20 seconds)."""
    time.sleep(delay)
    if os.path.exists(heic_path):
        os.remove(heic_path)
    if os.path.exists(jpg_path):
        os.remove(jpg_path)

def heic_to_jpg(request):
    converted_image_url = None
    jpg_filename = None

    if request.method == 'POST' and request.FILES.get('heic_file'):
        heic_file = request.FILES['heic_file']
        heic_path = default_storage.save(f"uploads/{heic_file.name}", heic_file)
        heic_full_path = default_storage.path(heic_path)

        jpg_folder = os.path.join(settings.MEDIA_ROOT, "processed")
        os.makedirs(jpg_folder, exist_ok=True)  # ✅ Ensure folder exists

        jpg_filename = heic_file.name.replace('.heic', '.jpg')
        jpg_path = os.path.join(jpg_folder, jpg_filename)
        jpg_relative_path = f"processed/{jpg_filename}"

        # Convert HEIC to JPG
        image = Image.open(heic_full_path)
        image.convert("RGB").save(jpg_path, "JPEG")  # ✅ Save after ensuring directory exists

        converted_image_url = default_storage.url(jpg_relative_path)

        # Start a separate thread to delete files after 1 minute
        threading.Thread(target=delete_files, args=(heic_full_path, jpg_path)).start()

    return render(request, 'tools/utilitytools/heic2jpg.html', {'converted_image_url': converted_image_url, 'jpg_filename': jpg_filename})


def download_jpg(request, filename):
    """Serve the converted JPG file for download."""
    jpg_path = os.path.join(settings.MEDIA_ROOT, "processed", filename)

    if os.path.exists(jpg_path):
        return FileResponse(open(jpg_path, "rb"), as_attachment=True, filename=filename)
    else:
        return render(request, 'tools/utilitytools/heic2jpg.html', {'error': 'File not found or expired.'})




# ======================= IMAGE BACKGROUND REMOVER ================



# def delete_files(original_path, processed_path, delay=60):
#     """Delete files after a specified delay (default: 60 seconds)."""
#     time.sleep(delay)
#     if os.path.exists(original_path):
#         os.remove(original_path)
#     if os.path.exists(processed_path):
#         os.remove(processed_path)


# def remove_background(request):
#     processed_image_url = None
#     processed_filename = None

#     if request.method == 'POST' and request.FILES.get('image_file'):
#         image_file = request.FILES['image_file']
#         input_path = default_storage.save(f"uploads/{image_file.name}", image_file)
#         input_full_path = default_storage.path(input_path)

#         output_folder = os.path.join(settings.MEDIA_ROOT, "processed")
#         os.makedirs(output_folder, exist_ok=True)

#         processed_filename = f"bg_removed_{image_file.name}"
#         output_path = os.path.join(output_folder, processed_filename)
#         output_relative_path = f"processed/{processed_filename}"

#         # Remove background
#         with open(input_full_path, 'rb') as f:
#             input_image = f.read()
#         output_image = remove(input_image)

#         # Save processed image
#         with open(output_path, 'wb') as f:
#             f.write(output_image)

#         processed_image_url = default_storage.url(output_relative_path)

#         # Auto-delete files after 1 minute
#         threading.Thread(target=delete_files, args=(input_full_path, output_path)).start()

#     return render(request, 'tools/utilitytools/rem_bg.html', {'processed_image_url': processed_image_url, 'processed_filename': processed_filename})


# def download_bg(request, filename):
#     """Serve the processed image for download."""
#     image_path = os.path.join(settings.MEDIA_ROOT, "processed", filename)

#     if os.path.exists(image_path):
#         return FileResponse(open(image_path, "rb"), as_attachment=True, filename=filename)
#     else:
#         return render(request, 'tools/utilitytools/rem_bg.html', {'error': 'File not found or expired.'})








# ================================pdf 2 image ==========================================

def delete_files_after_delay(files, delay=20):
    """Deletes the specified files after a delay."""
    def delete_files():
        time.sleep(delay)
        for file in files:
            if os.path.exists(file):
                os.remove(file)
    
    threading.Thread(target=delete_files, daemon=True).start()

def pdf_to_jpg(request):
    image_paths = []  # Store converted image paths

    if request.method == 'POST' and request.FILES.get('pdf_file'):
        pdf_file = request.FILES['pdf_file']
        pdf_filename = f"{int(time.time())}_{pdf_file.name}"  # Unique filename
        pdf_path = os.path.join(settings.MEDIA_ROOT, pdf_filename)

        # Save the uploaded PDF file
        with open(pdf_path, 'wb+') as destination:
            for chunk in pdf_file.chunks():
                destination.write(chunk)

        # Convert PDF to images
        images = convert_from_path(pdf_path)
        file_paths = [pdf_path]  # Store files for deletion

        for i, image in enumerate(images):
            image_name = f'{os.path.splitext(pdf_filename)[0]}_page_{i + 1}.jpg'
            image_path = os.path.join(settings.MEDIA_ROOT, image_name)
            image.save(image_path, 'JPEG')
            image_paths.append(os.path.join(settings.MEDIA_URL, image_name))
            file_paths.append(image_path)  # Store images for deletion

        # Schedule automatic deletion after 2 minutes
        delete_files_after_delay(file_paths, delay=20)

    return render(request, 'tools/utilitytools/pdf2imgs.html', {'image_paths': image_paths})






# ================Tools 2================

#  this is imag2pdf converter
def i2pconverter(files, output_pdf_path):
    """
    Convert multiple image files into a single PDF.
    """
    with open(output_pdf_path, 'wb') as f:
        f.write(img2pdf.convert(files))



def imgs2pdf(request):
    if request.method == 'POST' and request.FILES.getlist('img'):
        uploaded_files = request.FILES.getlist('img')  # Get multiple files
        fs = FileSystemStorage(location=settings.MEDIA_ROOT)
        
        # Save uploaded images and store their paths
        saved_file_paths = []
        for uploaded_file in uploaded_files:
            file_path = fs.save(uploaded_file.name, uploaded_file)
            full_path = os.path.join(settings.MEDIA_ROOT, file_path)
            saved_file_paths.append(full_path)
        
        # Output PDF file path
        output_pdf_path = os.path.join(settings.MEDIA_ROOT, 'converted_pdf_file.pdf')

        # Convert the images to a single PDF
        i2pconverter(saved_file_paths, output_pdf_path)

        # Store the converted PDF file path in the session
        request.session['converted_file'] = output_pdf_path

        # Delete the uploaded image files after conversion
        for file_path in saved_file_paths:
            if os.path.exists(file_path):
                os.remove(file_path)

        return render(request, 'tools/utilitytools/imgs2pdf.html', {'converted': True})

    return render(request, 'tools/utilitytools/imgs2pdf.html', {'converted': False})



def downd_imgs2pdf(request):
    file_path = request.session.get('converted_file')
    if file_path and os.path.exists(file_path):
        # Serve the PDF as a download
        response = FileResponse(open(file_path, 'rb'), as_attachment=True)

        # Clean up the original converted file after serving the response
        os.remove(file_path)  # Delete the converted file
        request.session.pop('converted_file', None)  # Remove file info from the session

        return response
    else:
        return HttpResponseNotFound("File not found")







# ================Tools 1================
#file converter 
@csrf_exempt
def Fileconverter(request):
    return render(request, "tools/utilitytools/onlinefileconverter.html")

# ================Tools 1================
#Video Downloader
def download_pinterest_video(url, save_dir):
    """
    Downloads a Pinterest video using a direct URL or HLS stream extraction.
    """
    try:
        print(f"Attempting to download Pinterest video from {url}")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        # Follow redirects to resolve the actual URL
        response = requests.get(url, headers=headers, allow_redirects=True)
        if response.status_code != 200:
            return f"Failed to retrieve the video: HTTP {response.status_code}"

        # Get the final redirected URL
        final_url = response.url
        print(f"Resolved URL: {final_url}")

        # Parse the webpage content
        soup = BeautifulSoup(response.text, 'html.parser')

        # Look for video tags or meta tags containing video URLs
        video_url = None
        video_tag = soup.find('video')
        if video_tag and video_tag.get('src'):
            video_url = video_tag['src']
        else:
            meta_tag = soup.find('meta', property="og:video")
            if meta_tag and meta_tag.get('content'):
                video_url = meta_tag['content']

        if not video_url:
            return "No video URL found in the provided Pinterest URL."

        print(f"Video URL found: {video_url}")

        # Generate a random filename for the downloaded video
        random_filename = f"{uuid.uuid4()}.mp4"
        video_filepath = os.path.join(save_dir, random_filename)

        # Use ffmpeg to download the video
        command = [
            'ffmpeg',
            '-y',  # Overwrite existing files
            '-i', video_url,
            '-c', 'copy',  # Copy streams without re-encoding
            video_filepath
        ]

        subprocess.run(command, check=True)
        print(f"Video downloaded successfully: {video_filepath}")
        return random_filename

    except subprocess.CalledProcessError as e:
        return f"ffmpeg error: {str(e)}"
    except Exception as e:
        return f"Error downloading Pinterest video: {e}"

def download_video(video_url, quality, save_dir, platform):
    """
    Handles video downloading using yt-dlp or custom logic for supported platforms.
    """
    retries = 3

    # yt-dlp format mapping based on quality
    quality_mapping = {
        "1080p": "bestvideo[height<=1080]+bestaudio/best[height<=1080]",
        "720p": "bestvideo[height<=720]+bestaudio/best[height<=720]",
        "480p": "bestvideo[height<=480]+bestaudio/best[height<=480]",
        "360p": "bestvideo[height<=360]+bestaudio/best[height<=360]",
        "144p": "bestvideo[height<=144]+bestaudio/best[height<=144]",
    }

    # Determine the format for yt-dlp
    selected_format = quality_mapping.get(quality, "best")  # Default to "best" if quality not found

    ydl_opts = {
        'format': selected_format,
        'outtmpl': os.path.join(save_dir, '%(id)s.%(ext)s'),
        'noplaylist': True,
        'merge_output_format': 'mp4',
        'quiet': False,
        'verbose': True,
        'socket_timeout': 60,
    }

    for attempt in range(retries):
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info_dict = ydl.extract_info(video_url, download=True)
                return f"{info_dict['id']}.mp4"  # Return the filename
        except Exception as e:
            print(f"Download attempt {attempt + 1} failed: {e}")
            if attempt == retries - 1:
                return f"All attempts failed: {e}"
            time.sleep(5)

def video_downloader(request):
    """
    Video downloader view to handle client requests for video downloads.
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            video_url = data.get('url')
            quality = data.get('quality', '720p')
            platform = data.get('platform')

            if not all([video_url, quality, platform]):
                return JsonResponse({'success': False, 'error': "Missing parameters."})

            save_dir = settings.MEDIA_ROOT
            os.makedirs(save_dir, exist_ok=True)

            # Call download_video with the specified platform
            video_filename = download_video(video_url, quality, save_dir, platform)

            # Validate file existence and format
            video_path = os.path.join(save_dir, video_filename)
            if not os.path.exists(video_path) or not video_filename.endswith('.mp4'):
                raise ValueError(f"Invalid file generated: {video_filename}")

            file_url = f"/media/{video_filename}"  # Generate the file URL

            # Start a background thread to delete the file after 1 minute
            deletion_thread = threading.Thread(target=delete_after_timeout, args=(video_filename, 60))
            deletion_thread.start()

            return JsonResponse({'success': True, 'file_url': file_url, 'download_filename': video_filename})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return render(request, "tools/utilitytools/videodownloader.html")

def delete_video(video_filename):
    """
    Deletes the specified video file.
    """
    video_filepath = os.path.join(settings.MEDIA_ROOT, video_filename)
    try:
        if os.path.exists(video_filepath):
            os.remove(video_filepath)
            print(f"Deleted file: {video_filename}")
        else:
            print(f"File not found: {video_filename}")
    except Exception as e:
        print(f"Error deleting file: {e}")

def delete_after_timeout(video_filename, delay=60):
    """
    Deletes a video file after a specified delay.
    """
    time.sleep(delay)  # Wait for the specified delay
    delete_video(video_filename)  # Call the delete function to remove the file
# ================Tools 1================
#Random Number Generator
def Randomnumgenerator(request):
    if request.method == "POST":
        try:
            # Get values from POST request
            min_value = int(request.POST.get("minValue"))
            max_value = int(request.POST.get("maxValue"))

            if min_value > max_value:
                return JsonResponse({"error": "Minimum value cannot be greater than the maximum value."}, status=400)

            # Generate random number
            random_number = random.randint(min_value, max_value)
            return JsonResponse({"random_number": random_number}, status=200)

        except (ValueError, TypeError):
            return JsonResponse({"error": "Invalid input. Please enter valid integers."}, status=400)

    return render(request, "tools/utilitytools/randomnumgenerator.html")

# ================Tools 1================
#QR code Generator and Scaner
def QRcodegenerators(request):
    return render(request, "tools/utilitytools/qrcodegenerator.html")

#Random Image Generator
def RandomImageGenerator(request):
    return render(request, "tools/utilitytools/randomimagegenerator.html")

# ====================== Security Tools ==================
# ================Tools 1================
#Password strength tester
def PasswordStrengthTester(request):
    return render(request, "tools/securitytools/passwordstrengthtester.html")

def test_password_strength(request):
    if request.method == "POST":
        import json
        data = json.loads(request.body)
        password = data.get("password", "")
        if not password:
            return JsonResponse({"error": "Password is required."}, status=400)
        
        # Simple password strength evaluation logic
        if len(password) < 6:
            strength = "Weak"
        elif len(password) < 12:
            strength = "Medium"
        else:
            strength = "Strong"
        return JsonResponse({"strength": strength})
    return JsonResponse({"error": "Invalid request method."}, status=405)

def generate_password(request):
    if request.method == "POST":
        import json
        data = json.loads(request.body)
        platform = data.get("platform", "general")
        
        length = 12  # Default password length
        if platform == "gmail":
            length = 16
        elif platform == "apple":
            length = 18
        elif platform in ["facebook", "instagram", "discord"]:
            length = 14
        
        characters = string.ascii_letters + string.digits + string.punctuation
        password = "".join(random.choices(characters, k=length))
        return JsonResponse({"password": password})
    return JsonResponse({"error": "Invalid request method."}, status=405)

# ================Tools 1================
#2FA Authentication Code Generator
def TwoFactorAuthentication(request):
    return render(request, "tools/securitytools/twofactorauthenticationcg.html")

# This view handles the AJAX request to generate the 2FA code
def generate_2fa_code(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            secret_key = data.get("secret_key")

            if not secret_key:
                return JsonResponse({"success": False, "message": "Secret key is required."}, status=400)

            # Create a TOTP object using the secret key
            totp = pyotp.TOTP(secret_key)
            code = totp.now()

            return JsonResponse({"success": True, "code": code})

        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)}, status=500)
    
    return JsonResponse({"success": False, "message": "Invalid request method."}, status=400)

    # ================Tools 1================



#IP Location Tracker
def IpLocationTracker(request):
    if request.method == "POST":
        ip_address = request.POST.get("ipInput")
        if ip_address:
            # Replace `API_URL` with your IP location API endpoint.
            API_URL = f"https://ipapi.co/{ip_address}/json/"  
            try:
                response = requests.get(API_URL)
                if response.status_code == 200:
                    data = response.json()
                    return JsonResponse({"success": True, "data": data})
                else:
                    return JsonResponse({"success": False, "error": "Failed to fetch location."})
            except Exception as e:
                return JsonResponse({"success": False, "error": str(e)})
        else:
            return JsonResponse({"success": False, "error": "Invalid IP address."})
    return render(request, "tools/securitytools/ipaddresslocationtra.html")


#Privacy Policy and Terms Generator
def PrivacyPolicyTermsGen(request):
    if request.method == 'GET':
        return render(request, "tools/securitytools/privacypolicytermsg.html")
    
    elif request.method == 'POST':
        try:
            # Parse JSON data from the request body
            data = json.loads(request.body)
            business_name = data.get('businessNameInput')
            website_url = data.get('websiteURLInput')

            # Generate a detailed privacy policy
            privacy_policy = f"""
            <h2 class="text-primary fw-bold">Privacy Policy for {business_name}</h2>
            <p class="text-muted">Last Updated: [Insert Date]</p>

            <p>Welcome to <strong>{business_name}</strong> (<a href="{website_url}" target="_blank">{website_url}</a>). We are committed to protecting your privacy and ensuring that your personal information is handled in a safe and responsible manner. This Privacy Policy outlines how we collect, use, and protect your information when you visit our website.</p>

            <h3 class="text-dark fw-bold mt-4">1. Information We Collect</h3>
            <p>We may collect the following types of information:</p>
            <ul>
                <li><strong>Personal Information:</strong> Name, email address, phone number, etc., provided by you when you fill out forms on our website.</li>
                <li><strong>Usage Data:</strong> Information about how you use our website, such as your IP address, browser type, pages visited, and time spent on the site.</li>
                <li><strong>Cookies:</strong> We use cookies to enhance your experience on our website. You can disable cookies in your browser settings if you prefer.</li>
            </ul>

            <h3 class="text-dark fw-bold mt-4">2. How We Use Your Information</h3>
            <p>We use the information we collect for the following purposes:</p>
            <ul>
                <li>To provide and maintain our website.</li>
                <li>To improve your experience on our website.</li>
                <li>To communicate with you, respond to inquiries, and send updates.</li>
                <li>To analyze website traffic and usage patterns.</li>
            </ul>

            <h3 class="text-dark fw-bold mt-4">3. Data Security</h3>
            <p>We take the security of your data seriously. We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, or misuse.</p>

            <h3 class="text-dark fw-bold mt-4">4. Third-Party Services</h3>
            <p>We may use third-party services (e.g., Google Analytics) to analyze website traffic. These services may collect information about your use of our website and are governed by their own privacy policies.</p>

            <h3 class="text-dark fw-bold mt-4">5. Your Rights</h3>
            <p>You have the right to:</p>
            <ul>
                <li>Access the personal information we hold about you.</li>
                <li>Request correction or deletion of your personal information.</li>
                <li>Opt-out of receiving communications from us.</li>
            </ul>

            <h3 class="text-dark fw-bold mt-4">6. Changes to This Privacy Policy</h3>
            <p>We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated revision date.</p>

            <h3 class="text-dark fw-bold mt-4">7. Contact Us</h3>
            <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:info@{website_url.split('//')[-1].split('/')[0]}">info@{website_url.split('//')[-1].split('/')[0]}</a>.</p>
            """

            # Return the generated policy as a JSON response
            return JsonResponse({'status': 'success', 'policy': privacy_policy})
        
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})