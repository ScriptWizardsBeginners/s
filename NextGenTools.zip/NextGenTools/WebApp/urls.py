from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('pricing/', views.pricing, name='pricing'),
    path('service/', views.service, name='service'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),




    # path('admin/', views.custom_admin_view, name='custom_admin'),
    # =================  Categories page ====================================================
    path('AipoweredTools/', views.Aipoweredtools, name='AipoweredTools'),
    path('Aicreativetools/', views.Aicreativetools, name='Aicreativetools'),
    path('Analytictools/', views.Analytictools, name='Analytictools'),
    path('Blockchaintools/', views.Blockchaintools, name='Blockchaintools'),
    path('Healthtools/', views.Healthtools, name='Healthtools'),
    path('Productivitytools/', views.Productivitytools, name='Productivitytools'),
    path('Securitytools/', views.Securitytools, name='Securitytools'),
    path('Socialmediatools/', views.Socialmediatools, name='Socialmediatools'),
    path('Trendbasedtools/', views.Trendbasedtools, name='Trendbasedtools'),
    path('Utilitytools/', views.Utilitytools, name='Utilitytools'),

    # =================== Tools ======================

    # ======================== 1. AI Powered tools ===========================
    # Text to speech converter
    path('Texttospeech/', views.Texttospeech, name='Texttospeech'),
    # Speech to Text converter
    path('Speechtotext/', views.Speechtotext, name='Speechtotext'),
    # VoiceCloning
    path('VoiceCloning/', views.VoiceCloning, name='VoiceCloning'),
    # Ai Content Generator
    path('Contentgenerator/', views.Contentgenerator, name='Contentgenerator'),
    path('Storygenerator/', views.Storygenerator, name='Storygenerator'),
    path('Resumebuilder/', views.Resumebuilder, name='Resumebuilder'),
    path('Videosummarizer/', views.Videosummarizer, name='Videosummarizer'),
    path('Presentation/', views.Presentation, name='Presentation'),
    path('Chatbotbuilder/', views.Chatbotbuilder, name='Chatbotbuilder'),
    # ======================== 1. Blockchain tools ===========================
    path('BlockchainWalletAddress/', views.BlockchainWalletAddress, name='BlockchainWalletAddress'),




    # ======================== 9. Utility tools ===========================
    # HEIC TO JPG
    path('heic_to_jpg/',views.heic_to_jpg,name='heic_to_jpg'),
    path('download/<str:filename>/',views.download_jpg, name='download_jpg'),


    # # remove bg

    # path('remove_bg/', views.remove_background, name='remove_background'),
    # path('download/<str:filename>/', views.download_bg, name='download_image'),

    
    # pdf to imgs converter
    path('pdf2imgs/',views.pdf_to_jpg, name='pdf_to_jpg'),


    # this url for img2pdf converter
    path('imgs2pdf/',views.imgs2pdf,name='imgs2pdf'),
    path('downd_imgs2pdf/',views.downd_imgs2pdf,name='downd_imgs2pdf'),


    # Online file converter
    path('Fileconverter/', views.Fileconverter, name='Fileconverter'),
    #Video Downloader
    path('video_downloader/', views.video_downloader, name='video_downloader'),
    path('delete_video/<str:video_filename>/', views.delete_video, name='delete_video'),
    # Random Number Generator
    path('Randomnumgenerator/', views.Randomnumgenerator, name='Randomnumgenerator'),
    # QR code Generator and Scaner
    path('QRcodegenerators/', views.QRcodegenerators, name='QRcodegenerators'),
    # Random Image Generator
    path('RandomImageGenerator/', views.RandomImageGenerator, name='RandomImageGenerator'),

    # ======================== 1. Security tools ===========================
    # Password strength tester and generator
    path("PasswordStrengthTester/", views.PasswordStrengthTester, name="PasswordStrengthTester"),
    path("test_password_strength/", views.test_password_strength, name="test_password_strength"),
    path("generate-password/", views.generate_password, name="generate_password"),

    #2FA Authentication Code Generator
    path('TwoFactorAuthentication/', views.TwoFactorAuthentication, name='TwoFactorAuthentication'),
    path('generate-2fa-code/', views.generate_2fa_code, name='generate_2fa_code'),

    #IP Location Tracker
    path('IpLocationTracker/', views.IpLocationTracker, name='IpLocationTracker'),

    #Privacy Policy and Terms Generator
    path('PrivacyPolicyTermsGen/', views.PrivacyPolicyTermsGen, name='PrivacyPolicyTermsGen'),



]

