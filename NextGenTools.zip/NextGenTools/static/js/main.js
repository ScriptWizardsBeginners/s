(function () {
  "use strict";

  /**
   * Add or remove the `scrolled` class based on scroll position.
   */
  let debounceTimer;
  const toggleScrolled = () => {
    const body = document.body;
    const header = document.querySelector("#header");
    if (
      header.classList.contains("scroll-up-sticky") ||
      header.classList.contains("sticky-top") ||
      header.classList.contains("fixed-top")
    ) {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        body.classList.toggle("scrolled", window.scrollY > 100);
      }, 100); // Delay scroll toggle by 100ms to optimize performance
    }
  };

  /**
   * Toggle mobile navigation menu.
   */
  const mobileNavToggleBtn = document.querySelector(".mobile-nav-toggle");
  const toggleMobileNav = () => {
    document.body.classList.toggle("mobile-nav-active");
    mobileNavToggleBtn.classList.toggle("bi-list");
    mobileNavToggleBtn.classList.toggle("bi-x");
  };

  if (mobileNavToggleBtn) {
    mobileNavToggleBtn.addEventListener("click", toggleMobileNav);
  }

  /**
   * Close mobile nav on same-page or hash link click.
   */
  const navLinks = document.querySelectorAll("#navmenu a");
  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      if (document.body.classList.contains("mobile-nav-active")) {
        toggleMobileNav();
      }
    });
  });

  /**
   * Preloader functionality.
   */
  const preloader = document.querySelector("#preloader");
  if (preloader) {
    window.addEventListener("load", () => preloader.remove());
  }

  /**
   * Scroll-to-top button.
   */
  const scrollTopButton = document.querySelector(".scroll-top");
  const toggleScrollTop = () => {
    if (scrollTopButton) {
      scrollTopButton.classList.toggle("active", window.scrollY > 100);
    }
  };

  if (scrollTopButton) {
    scrollTopButton.addEventListener("click", (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /**
   * Initialize animation on scroll (AOS).
   */
  const initializeAOS = () => {
    AOS.init({
      duration: 600,
      easing: "ease-in-out",
      once: true,
      mirror: false,
    });
  };

  /**
   * Initialize GLightbox.
   */
  const initializeGLightbox = () => {
    GLightbox({ selector: ".glightbox" });
  };

  /**
   * Initialize Swiper sliders.
   */
  const initializeSwipers = () => {
    document.querySelectorAll(".init-swiper").forEach((swiperElement) => {
      const configElement = swiperElement.querySelector(".swiper-config");
      if (configElement) {
        const config = JSON.parse(configElement.innerHTML.trim());
        new Swiper(swiperElement, config);
      }
    });
  };

  /**
   * Frequently Asked Questions (FAQ) toggle.
   */
  const faqItems = document.querySelectorAll(
    ".faq-item h3, .faq-item .faq-toggle"
  );
  faqItems.forEach((faqItem) => {
    faqItem.addEventListener("click", () => {
      faqItem.parentNode.classList.toggle("faq-active");
    });
  });

  /**
   * Adjust scroll position for hash links on page load.
   */
  const adjustHashScrollPosition = () => {
    if (window.location.hash) {
      const targetSection = document.querySelector(window.location.hash);
      if (targetSection) {
        setTimeout(() => {
          const scrollMarginTop = parseInt(
            getComputedStyle(targetSection).scrollMarginTop || 0
          );
          window.scrollTo({
            top: targetSection.offsetTop - scrollMarginTop,
            behavior: "smooth",
          });
        }, 100);
      }
    }
  };

  /**
   * Highlight active nav links based on scroll position.
   */
  const navMenuLinks = document.querySelectorAll(".navmenu a");
  const highlightNavLinks = () => {
    navMenuLinks.forEach((link) => {
      if (!link.hash) return;
      const section = document.querySelector(link.hash);
      if (section) {
        const position = window.scrollY + 200;
        const isActive =
          position >= section.offsetTop &&
          position <= section.offsetTop + section.offsetHeight;
        link.classList.toggle("active", isActive);
      }
    });
  };

  /**
   * Event Listeners
   */
  window.addEventListener("scroll", () => {
    toggleScrolled();
    toggleScrollTop();
    highlightNavLinks();
  });

  window.addEventListener("load", () => {
    toggleScrolled();
    toggleScrollTop();
    initializeAOS();
    initializeGLightbox();
    initializeSwipers();
    adjustHashScrollPosition();
    highlightNavLinks();
  });
})();







// =============================Tools icon slider==================================
document.addEventListener("DOMContentLoaded", function () {
  const swiper = new Swiper(".swiper-container", {
    // Core configuration
    slidesPerView: 6,
    spaceBetween: 25,
    centeredSlides: true,
    loop: true,
    loopAdditionalSlides: 5, // Ensures smooth infinite transition
    autoplay: {
      delay: 2500,
      disableOnInteraction: false,
      waitForTransition: true, // Prevents glitches during fast transitions
      pauseOnMouseEnter: true, // Built-in hover pause
    },
    speed: 600, // Slightly faster for smoother feel
    grabCursor: true, // Visual feedback on hover

    // Responsive breakpoints
    breakpoints: {
      320: { // More granular mobile control
        slidesPerView: 2,
        spaceBetween: 15
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20
      },
      1024: {
        slidesPerView: 4,
        spaceBetween: 25
      },
      1440: {
        slidesPerView: 6
      }
    },

    // Optional enhancements
    keyboard: {
      enabled: true, // Keyboard navigation
      onlyInViewport: true
    },

  });

  // Cleaner hover control using container instead of individual slides
  const container = document.querySelector(".swiper-container");
  container.addEventListener("mouseenter", () => swiper.autoplay.stop());
  container.addEventListener("mouseleave", () => swiper.autoplay.start());
});